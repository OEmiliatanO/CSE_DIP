from PIL import Image

def rotate(img, ang, expand):
	return img.rotate(ang, expand = expand)
