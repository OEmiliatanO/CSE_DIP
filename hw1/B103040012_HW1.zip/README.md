the packages i used is in requirements.txt. please use pip to install the packages:  
```pip3 install -r requirements.txt```  

my version of Python is "3.10.6". and my version of pip is "22.2.2".  

use ```python3 hw1.py``` to open the application.
